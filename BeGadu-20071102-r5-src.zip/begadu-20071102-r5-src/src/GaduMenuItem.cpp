
#include <String.h>

#include "GaduMenuItem.h"
#include "GfxStuff.h"

GaduMenuItem::GaduMenuItem(  BBitmap *aIcon = NULL, const char *aLabel = NULL, BMessage *aMessage = NULL) : BMenuItem( aLabel, aMessage ) {
	if( aIcon )
		iIcon = aIcon;
	iLabel = new BString( aLabel );
}

GaduMenuItem::~GaduMenuItem() {
	delete iLabel;
}

void GaduMenuItem::DrawContent() {
	BRect frame = Frame();
	frame.left += 2;
	frame.top += 2;
	frame.bottom = frame.top + 20;
	BRect r( frame.left,
			 frame.top,
			 frame.left + 18,
			 frame.top + 16);
	Menu()->SetDrawingMode(B_OP_ALPHA);
	Menu()->SetLowColor(0, 0, 0, 255);

	if(iIcon)
		Menu()->DrawBitmap( iIcon, r );

	frame.left += 2;
	Menu()->SetDrawingMode(B_OP_OVER);
	Menu()->MovePenTo(frame.left + 21, (((frame.bottom+frame.top)/2.0))+4.0);
	Menu()->DrawString( iLabel->String());
}

void GaduMenuItem::GetContentSize( float *aWidth, float *aHeight ) {
	BMenuItem::GetContentSize( aWidth, aHeight );
	*aHeight = 20;
}
