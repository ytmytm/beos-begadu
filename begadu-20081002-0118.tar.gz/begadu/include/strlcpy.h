#include <sys/types.h>

size_t strlcpy(char *dst, const char *src, size_t size);
